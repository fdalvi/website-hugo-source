#include <stdio.h>

#define MAC(x) (x+2)
#define MAC2(x,y) (x+y)

int main()
{
  printf("Macro 1: %d\n", MAC(5));
  printf("Macro 2: %d\n", MAC2(5,2));
  return 0;
}
