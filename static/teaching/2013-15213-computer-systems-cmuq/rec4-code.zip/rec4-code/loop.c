#include <stdio.h>

void loop() {
  int i=0;
  do {
    printf("Hello\n");
    i++;
  }while(i < 10);
}

void forloop() {
  int i;
  for(i=0; i<10; i++) {
    printf("Hello\n");
  }
}
int main()
{
  forloop();
  return 0;
}
