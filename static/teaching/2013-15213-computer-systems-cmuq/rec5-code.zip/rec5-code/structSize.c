#include <stdio.h>

struct someStruct {
  char oneChar;
  int someInt;
  char someChar;
  char someOtherChar;
  char* aPtr;
};

struct betterStruct {
  int someInt;
  char* aPtr;
  char oneChar;
  char someChar;
  char someOtherChar;
};

union someUnion {
  char oneChar;
  int someInt;
  char someChar;
  char someOtherChar;
  char* aPtr;
};

int main() {
  printf("someStruct Size %d\n", sizeof(struct someStruct));
  printf("betterStruct Size %d\n", sizeof(struct betterStruct));
  printf("someUnion Size %d\n", sizeof(union someUnion));
  return 0;
}
