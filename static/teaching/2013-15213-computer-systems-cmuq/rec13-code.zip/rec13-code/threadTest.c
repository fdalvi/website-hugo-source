#include<stdio.h>
#include<pthread.h>

char **ptr; /* global */ 

void *thread(void *vargp) 
{ 
  int myid = *(int *)vargp;
  while(1) {
    //myid++;
    *(int *)vargp = *(int *)vargp +1;
  }


}

int main() 
{ 
  int i; 

  pthread_t tid; 

    pthread_create(&tid, NULL, thread, (void *)&i); 

    while(1)
      printf("%d\n",i);
  pthread_exit(NULL); 

} 
