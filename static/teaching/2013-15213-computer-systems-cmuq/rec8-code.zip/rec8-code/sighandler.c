#include <stdio.h>
#include <signal.h>

int counter = 1;

void handler(int signum)
{
  counter--;
}

int main()
{
  signal(SIGALRM,handler);
  kill(0,SIGALRM);
  counter++;
  printf("%d\n",counter);
  return 0;
}
