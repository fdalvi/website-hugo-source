#include <stdio.h>
#include <unistd.h>

int main()
{
	pid_t result = fork();
	printf("Print 1!\n");
	if (result == 0)
	{
		//Execute only in child
		char* cmd = "/bin/echo";
		char* args[] = {cmd, "hello","world","from","child"};
		execvp(cmd,args);
		printf("Print 2!\n");
	}
	else
	{
		//Execute only in parent
		printf("Print 3!\n");
	}
	return 0;
}
