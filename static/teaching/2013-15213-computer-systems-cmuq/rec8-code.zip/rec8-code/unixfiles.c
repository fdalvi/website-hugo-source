#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>


int main()
{
	int fd = open("ab.txt", O_RDONLY);
	char c;
	fork();
	read(fd,&c,1); //Read one character from the file
	printf("%c\n",c); //Print the character
	return 0;
}
