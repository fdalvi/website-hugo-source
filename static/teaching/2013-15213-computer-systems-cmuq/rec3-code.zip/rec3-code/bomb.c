#include <stdio.h>

void checkBomb(int input) {
	if(input == 15213)
    	printf("Phew, bomb defused.\n");
  	else
    	printf("Boooom!\n");
}

int main()
{
  int userInput;
  scanf("%d", &userInput);
  
  checkBomb(userInput);
  
  return 0;
}
